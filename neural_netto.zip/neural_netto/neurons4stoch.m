%neurons4stoch
clear all
close all
dns=6;
neunum=dns*dns;
sir=0;
cr=6;
for i=1:dns
    for g=1:dns
        sir=sir+1;
        strofeacneu(sir).col=i;
        strofeacneu(sir).raw=g;
    end
end
[neuron(1:16).firid]=deal([]);
[neuron(1:16).APtime] = deal([]);
%[neuron(1:16).aff]=deal([0]);
randneu=5;
neuwmat=zeros(neunum/2);
th_w=0.5;
init=1;
for i=1:neunum
    for g=1:neunum
        if i==g
            strofeacneu(i).neuwmat(g)=0;
        else
            neuwmat(i,g)=rand(1);
            if neuwmat(i,g)>th_w
                strofeacneu(i).neuwmat(g)=neuwmat(i,g);
            else
                strofeacneu(i).neuwmat(g)=0;
            end
        end
    end
end
inc=15;
dongu=1;
dt = 0.01;
sayi=randi(neunum/2,1);
newneuros=randperm(neunum,round(sayi/2));
ilkler=newneuros;
neuros=newneuros;
for ai=1:neunum
        for ah=1:size(neuros,2)
            dis1=abs(strofeacneu(ai).col-strofeacneu(neuros(1,ah)).col);
            dis2=abs(strofeacneu(ai).raw-strofeacneu(neuros(1,ah)).raw);
            dist(ah,ai)=dt*(dis1+dis2)+10; %seperately calculate for each neuron
        end
end
exceed_thr=0;
if numel(neuros)>5
    allneurons_spike=zeros(neunum,2);
    spike_time=0;
    zmap=zeros(dns,dns);
    zmap(newneuros)=1;
    imagesc(zmap)
    circle4lif;
    eventsoffire;
   
else
    haaaa=1;
end

