%summation
dolu=0;

for hii=1:size(neuron(ii).firid,2)
    if numel(neuron(ii).firid(hii))>0
        dolu=dolu+1;
        if dolu==1
         epsp=neuron(ii).firid(hii).V;
        else dolu>1
            epsp=epsp+(neuron(ii).firid(hii).V +70);
            
    end
     
    end
    
end
for ms=1:size(epsp,2)%size(neuron(ii).firid(hii).V,2)  
                if epsp(1,ms)>V_thresh;
                     %epsp=V_reset%neuron(ii).firid(hii).V(1,ms:end)=V_reset
                     neuron(ii).APtime=time(1,ms);
                     exceed_thr=exceed_thr+1;
                     newneuros(1,exceed_thr)=ii;
                    break;
                end
        end  
%makeplots;
   pause(2)
   close all  
