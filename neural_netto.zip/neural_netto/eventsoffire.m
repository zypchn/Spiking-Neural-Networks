%eventsoffire
%if thefirstfire==init
%neu_more_list=[];
exceed_thr=0;
newneuros=[];
for ii=1:neunum
    ind=0;
    %afferents=sütun*********************************önnemli bu
    potensofneu(ii).V(1) =-70;
    divt=0
    ipa=0;
    if isnan(neuros)==0 & sum(neuros==ii)>0
        ipa=inc;
%         neu_more_list(ii,1)=1;
%         neu_more_list(ii,2)=ipa;
    elseif isnan(neuros)==0 & sum(neuros==ii)==0
        lif4pulse4;
%          neu_more_list(ii,1)=1;
%          neu_more_list(ii,2)=ipa;
    else
%          neu_more_list(ii,1)=0
%          neu_more_list(ii,2)=ipa;
    end
    allneurons_spike(ii,1)=divt;
    allneurons_spike(ii,2)=ipa;

end
circle4lif;
