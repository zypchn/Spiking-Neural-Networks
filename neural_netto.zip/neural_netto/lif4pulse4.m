%lif4pulse
% Leaky Integrate-and-Fire (LIF) Neuron Model
% Leaky Integrate-and-Fire (LIF) Neuron Model with Single Pulse

% Parameters
R = 1;            % Membrane resistance
C = 1;            % Membrane capacitance
tau = R * C;      % Membrane time constant
V_rest = -70;     % Resting membrane potential
V_thresh = -70+inc;   % Threshold potential
V_reset = V_rest; % Reset potential
dt = 0.01;        % Time step

% Input pulse

%pulse_start = 10;    % Pulse start time
pulse_duration = 1;  % Pulse duration

% Simulation
T = 1;            % Total simulation time
num_steps = T / dt; % Number of time steps

% Initialize variables

%V = zeros(1, num_steps)+-70;%### işaretli satırla muadil, tutmazsa bu
%satıra dön
time = (1:num_steps) * dt;

% Main simulation loop
%ipa=25
aj=0
for jg=1:size(neuros,2)
    mv=[1:neunum]==neuros';
    if dongu==1 
        pulse_start=dt*dist(jg,ii) ; %IPStiming çalışıtor
    elseif dongu>1 && numel(neuron(neuros(1,jg)).APtime)>0
        pulse_start=neuron(neuros(jg)).APtime;
    elseif dongu>1 && numel(neuron(neuros(1,jg)).APtime)==0
        pulse_start=0;
    end
    %IPSPtiming% burada pulse_start belirleniyor
    neuron(ii).firid(jg).V=zeros(1, num_steps)+-70;%  
    for t = 2:num_steps
        % Apply input pulse
        if time(t) >= pulse_start && time(t) < pulse_start + pulse_duration && pulse_start>0
            I = cr*neuwmat(neuros(1,jg),ii); % Amplitude of input pulse which 
        else                                %is current rate (cr)*weight of synaps
            I = 0; % No input pulse
        end
        % Update membrane potential using LIF model equation
        dV = (-(neuron(ii).firid(jg).V(t-1) - V_rest) + R * I) / tau * dt;
        neuron(ii).firid(jg).dV(t)=dV;
        neuron(ii).firid(jg).V(t) = neuron(ii).firid(jg).dV(t) + neuron(ii).firid(jg).V(t-1);
        neuron(ii).firid(jg).divt(t)=time(t);
        neuron(ii).firid(jg).aff=neuros(1,jg);

    end
aj=aj+1;
end

summation;
%%
