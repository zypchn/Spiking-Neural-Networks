%makeplots
% Plot results

figure;
subplot(2,1,1);
plot(time, epsp, 'b', 'LineWidth', 2);
title('LIF Neuron Model');
xlabel('Time (ms)');
ylabel('Membrane Potential');

subplot(2,1,2);
plot(time, neuron(ii).firid(hii).V >= V_thresh, 'r', 'LineWidth', 2);
title('Spikes');
xlabel('Time (ms)');
ylabel('Spike Occurrence');

% Highlight the input pulse period
% hold on;
% ylim([-75, -50]);
% patch([pulse_start, pulse_start, pulse_start + pulse_duration, pulse_start + pulse_duration], [-75, -50, -50, -75], 'g', 'FaceAlpha', 0.3);
% hold off;


% figure;
% subplot(2,1,1);
% plot(time, V, 'LineWidth', 2);
% title('Leaky Integrate-and-Fire Neuron');
% xlabel('Time');
% ylabel('Membrane Potential');
% grid on;
% 
% subplot(2,1,2);
% % if ~isnan(spike_time)
% %     plot(spike_time, V_th, 'ro', 'MarkerSize', 10); % Mark spike time
% % end
% plot(allneurons_spike(:,1),V_th, 'ro', 'MarkerSize', 10)
% title('Spike Detection');
% xlabel('Time');
% ylabel('Membrane Potential');
% grid on;


% % Display spike time
% if ~isnan(spike_time)
%     fprintf('Spike detected at time %.2f seconds.\n', spike_time);
% else
%     fprintf('No spike detected within the simulation time.\n');
% end
