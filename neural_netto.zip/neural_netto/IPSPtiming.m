%IPSPtiming
%burada dert pulsun başladığı teri zamanda denk geitmek. Pulsun başladığı
%yeri 10 ms + uzaklık belirliyor. Burada diyelimki 12.2 ms de bir nöron
%ateşlemiş bunu aşağıda dV denklemine oradan nasıl sokacağız. Bunu bir
%biçimde yapacağız.
dist=[];
for ai=1:neunum
        for ah=1:size(neuros,2)
        dis1=abs(strofeacneu(ai).col-strofeacneu(neuros(1,ah)).col);
        dis2=abs(strofeacneu(ai).raw-strofeacneu(neuros(1,ah)).raw);
        dist(ah,ai)=dt*(dis1+dis2)+neuron(neuros(ah)).APtime; %seperately calculate for each neuron
        end
    end

