%circle4lif
while exceed_thr>0 & dongu<6 
    neuros=newneuros;
    sys_activity(dongu).neuron=neuron;
    sys_activity(dongu).newneuros=newneuros;
    dongu=dongu+1;
    seeactmap
    %makeplots
    pause(4)
    eventsoffire;
end
        
        
    %end


