%seeactmap
zmap=zeros(dns,dns);
zmap(newneuros)=1;
% for i=1:neunum
%     if allneurons_spike(i,2)>inc
%         zmap(i)=1;
%     else
%         zmap(i)=0;
%     end
% end
imagesc(zmap);